insert into DETAILS_OF_EMP
values(123, 'Kumar');