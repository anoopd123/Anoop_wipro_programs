insert into DETAILS_OF_EMP
values(20090906, 'Anoop');
insert into DETAILS_OF_EMP
values(4567, 'Anoop kumar');