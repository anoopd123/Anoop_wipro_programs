package com.anoop.demo.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.anoop.demo.interfaces.DoeRepos;
import com.anoop.demo.model.DetailsOfEmp;

@Controller
public class EmployeeController {
	@Autowired
	DoeRepos repo;
	@RequestMapping("/")
	public String home() {
		return "home.jsp";
	}
	@RequestMapping("/addEmployees")
	/*public ModelAndView addEmployess(DetailsOfEmp doe) {
		ModelAndView mv=new ModelAndView(repo);
		return mv;
	}*/
	public String addEmployees(DetailsOfEmp doe)
	{
		repo.save(doe);
		return "home.jsp";
	}
	@RequestMapping("/getEmployees")
	public ModelAndView getEmployees(@RequestParam int id)
	{
		ModelAndView mv=new ModelAndView("showemp.jsp");
		DetailsOfEmp doe=repo.findById(id).orElse(new DetailsOfEmp());
		return mv;
		
	}
	 
}
