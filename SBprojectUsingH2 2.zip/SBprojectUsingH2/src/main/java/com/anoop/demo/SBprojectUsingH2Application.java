package com.anoop.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SBprojectUsingH2Application {

	public static void main(String[] args) {
		SpringApplication.run(SBprojectUsingH2Application.class, args);
	}

}
