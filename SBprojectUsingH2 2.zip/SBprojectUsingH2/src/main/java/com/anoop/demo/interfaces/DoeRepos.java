package com.anoop.demo.interfaces;
import org.springframework.data.repository.CrudRepository;
import com.anoop.demo.model.DetailsOfEmp;
public interface DoeRepos extends CrudRepository<DetailsOfEmp, Integer>{

}
