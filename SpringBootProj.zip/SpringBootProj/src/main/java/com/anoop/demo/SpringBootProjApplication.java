package com.anoop.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootProjApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProjApplication.class, args);
	}

}
