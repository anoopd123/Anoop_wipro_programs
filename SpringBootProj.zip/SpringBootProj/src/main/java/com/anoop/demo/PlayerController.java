package com.anoop.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PlayerController {
	@Autowired
	private PlayerService playerservice;
	@RequestMapping("/")
	public String home() {
		return "playersinfo.jsp";
	}
	//Get
	@RequestMapping(value="/players",method=RequestMethod.GET)
	public List<Player> getPlayers(){
		return playerservice.getAllPlayers();
	}
	@RequestMapping(value="/players/{id}", method=RequestMethod.GET)
	public Player getSinglePlayer(@PathVariable int id)
	{
		return playerservice.getOnePlayer(id);
	}
	@RequestMapping(value="players/save",method=RequestMethod.POST)
	public void savePlayer(@RequestBody Player player)
	{
		playerservice.saveplayer(player);
	}
	@RequestMapping(value="players/update",method=RequestMethod.PUT)
	public void updatePlayer(@RequestBody Player player)
	{
		playerservice.saveplayer(player);
	}
	@RequestMapping(value="/players/delete",method=RequestMethod.DELETE)
	public void deleteplayer(int idd)
	{
		playerservice.deleteplayer(idd);
	}
	
	
	
}
