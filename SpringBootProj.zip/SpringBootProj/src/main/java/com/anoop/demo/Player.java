package com.anoop.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
//@Table(name="PLAYER")

public class Player {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="PLayer Id")
	private int id;
	@Column(name="Player Name")
	private String playername;
	
	public Player(int id, String playername) {
		this.id=id;
		this.playername=playername;
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPlayername() {
		return playername;
	}

	public void setPlayername(String playername) {
		this.playername = playername;
	}

	@Override
	public String toString() {
		return "Player [id=" + id + ", name=" + playername + "]";
	}

}
