/*package com.anoop.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service 
public class PlayerService {
	/*List<Player> list=new ArrayList<>();
 public PlayerService()
 {
	 System.out.println("Player Service is Created");
	 list.add(new Player(1,"anoop1"));
	 list.add(new Player(2,"kumar1"));
	 list.add(new Player(3,"dande1"));
	 
 }
	
 public List<Player> getAllPlayers(){
	 return list;
 }
 public Player getOnePlayer(int id)
 {
	 return list.get(id);
 }
 public void saveplayer(Player player)
 {
	 this.list.add(player);
 }
 public void updateplayer(Player player)
 {
	 for(Player pp:list)
	 {
		 if(pp.getId()==player.getId())
		 {
			 pp.setPlayername(player.getPlayername());
		 }
	 }
 }
 public void deleteplayer(int idd)
 {
	 for(Player pp:list)
	 {
		 if(pp.getId()==idd)
		 {
			 list.remove(idd);
			 System.out.println("Player with"+idd+"has been removed");
		 }
	 }
 }
 
}*/




package com.anoop.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.bytebuddy.dynamic.DynamicType.Builder.FieldDefinition.Optional;

@Service 
public class PlayerService {
	/*List<Player> list=new ArrayList<>();
 public PlayerService()
 {
	 System.out.println("Player Service is Created");
	 list.add(new Player(1,"anoop1"));
	 list.add(new Player(2,"kumar1"));
	 list.add(new Player(3,"dande1"));
	 
 }*/
	@Autowired
	PlayerRepository playerrepo;
 public List<Player> getAllPlayers(){
	 List<Player> playerlist=new ArrayList<>();
	 playerrepo.findAll().forEach(playerlist::add);
	 return playerlist;
 }
 public Player getOnePlayer(int id)
 {
	 java.util.Optional<Player> oneplayer=playerrepo.findById(id);
	 if(oneplayer.isPresent()) { return oneplayer.get();}
	 else return null;
 }
 public void saveplayer(Player player)
 {
	 playerrepo.save(player);
 }
 public void updateplayer(Player player)
 {
	 playerrepo.save(player);
 }
 public void deleteplayer(int idd)
 {
	 playerrepo.deleteById(idd);
 }
 
}
